import React from "react";

function LoginPage() {
  return (
    <>
      <div>
        <h2>회원가입</h2>
      </div>
      <div>
        <label htmlFor="email">이메일</label>
        <br />
        <input id="email" type="text" placeholder="이메일 입력" />@
        <select name="email_select">
          <option value="gmail.com">gamil.com</option>
          <option value="naver.com">naver.com</option>
          <option value="daum.net">daum.net</option>
        </select>
      </div>

      <div>
        <label htmlFor="password">비밀번호</label>
        <br />
        <input id="password" type="password" placeholder="비밀번호 입력" />
      </div>

      <div>
        <label htmlFor="password">비밀번호 확인</label>
        <br />
        <input id="password1" type="password" placeholder="비밀번호 확인" />
      </div>

      <div>
        <label htmlFor="nickname">닉네임</label>
        <br />
        <input type="text" placeholder="nickname" />
      </div>

      <div>
        <label htmlFor="sex">성별</label>
        <br />
        <select name="sex">
          <option value selected>
            성별
          </option>
          <option value="M">남자</option>
          <option value="F">여자</option>
        </select>
      </div>

      <div>
        <label htmlFor="phone">전화번호</label>
        <br />
        <input id="phone" type="tel" placeholder="휴대폰번호" />
      </div>

      <div>
        <label htmlFor="addr">주소</label>
        <br />
        <input id="addr1" type="text" /> <br />
        <input id="addr2" type="text" />
        기본 주소 <br />
        <input id="addr3" type="text" />
        나머지 주소
      </div>
    </>
  );
}

export default LoginPage;
